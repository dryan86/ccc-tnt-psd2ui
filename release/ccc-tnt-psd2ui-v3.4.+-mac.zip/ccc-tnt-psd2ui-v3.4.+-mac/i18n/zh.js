"use strict";
module.exports = {
    menu: "psd2ui",
    open_panel: "主面板",
    send_to_panel: "发送消息给面板",
    description: "含有一个基于Vue3.x开发的面板的扩展"
};